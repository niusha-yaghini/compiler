bombs = [[False for y in range(80)] for x in range(5)]
bombs[0][1] = True
bombs[3][5] = True
bombs[4][7] = True
hint = False
if hint:
	for r, row in enumerate(bombs):
		for c, column in enumerate(row):
			if column:
				print('*', end='')
			else:
				cnt = 0
				for x in range(r - 1, r + 2):
					for y in range(c - 1, c + 2):
						if 0 <= x < len(bombs) and 0 <= y < len(bombs[r]):
							if bombs[x][y]:
								cnt += 1
				if cnt:
					print(cnt, end='')
				else:
					print('#', end='')
		print()
else:
	for row in bombs:
		for column in row:
			if not column:
				print('#', end ='')
			else:
				print('*', end ='')
		print()